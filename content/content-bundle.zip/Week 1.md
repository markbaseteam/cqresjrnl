## Classwork
Carl made us introduce ourselves first thing in class today, this is my #1 most hated thing when in a new class, at least we didn't have to tell random stories about ourselves.
## Personal Research
Questions for your [journal](https://ecampus.nmit.ac.nz/moodle/course/view.php?id=13776&section=1 "Journal"):

-   What is research?
-   What is the purpose of research?
-   What aspect of IT would you be interested in doing more research? Be as specific as you can.

These questions are not really relevant to a level 7 class as by now the meaning and purpose of research should be very much already experienced.
I'm rly interested in cybersecurity so it follows i would be interested in research on that. there are so many areas of focus within the subject though but i'm not sure on the specifics exactly of what i want to get into. i feel like if i had more spare time that i could devote to that then i would be able to really refine what knowledge and expertise i would want. there is so much you could pick from which could seem overwhelming at first but its kinda like doing a degree in IT, you do a bit of everything and once you've understood through practical work, you realize what your strengths are or what things you can't stand. But as with everything, a lot of time is involved in that which is always something I have minimal of.