# Week 1
## Classwork
Carl made us introduce ourselves first thing in class today, this is my #1 most hated thing when in a new class, at least we didn't have to tell random stories about ourselves.
## Personal Research
Questions for your journal:

-   What is research?
-   What is the purpose of research?
-   What aspect of IT would you be interested in doing more research? Be as specific as you can.

These questions are not really relevant to a level 7 class as by now the meaning and purpose of research should be very much already experienced.
I'm rly interested in cybersecurity so it follows i would be interested in research on that. there are so many areas of focus within the subject though but i'm not sure on the specifics exactly of what i want to get into. i feel like if i had more spare time that i could devote to that then i would be able to really refine what knowledge and expertise i would want. there is so much you could pick from which could seem overwhelming at first but its kinda like doing a degree in IT, you do a bit of everything and once you've understood through practical work, you realize what your strengths are or what things you can't stand. But as with everything, a lot of time is involved in that which is always something I have minimal of.


# Week 2
## Classwork
Quantitative data can tell you “how many,” “how much,” or “how often”—for example, how many people attended last week’s webinar? How much revenue did the company make in 2019? How often does a certain customer group use online banking?

Researchers will often turn to qualitative data to answer “Why?” or “How?” questions. For example, if your quantitative data tells you that a certain website visitor abandoned their shopping cart three times in one week, you’d probably want to investigate why—and this might involve collecting some form of qualitative data from the user. Perhaps you want to know how a user feels about a particular product; again, qualitative data can provide such insights.

#### Research Methods

**Quantitative**

-   Analytical tools
-   Surveys
-   Questionnaires
-   Environmental sensors (device that detects changes and sends stream of info to computer)

**Qualitative**

-   Interviews
-   Surveys
-   Questionnaires
-   Observations

#### Are computer programs quantitative or qualitative?

I'm not sure whether you can accurately define an object itself like a piece of software as easy as a piece of data on whether it is quant or qual, but at a guess I would say computer programs are quantitative because they are structured in code which is made up of data and values n shit, these are factual, defining what the program will do. This is not a 'feeling' or 'description' as qualitative says.

### Paper Analysis

-   Read the abstract (at least). You may need to do additional personal research to understand some of the concepts in the paper. You are not required to understand the paper in its entirety.
-   Skim through the paper and identify how it's structure relates to the quantitative research diagram above.
-   Determine whether the research is qualitative or quantitative or mixed-method.
-   If the paper is not mixed-method, would the research benefit from a mixed-method approach? Why (or why not)? Why might the authors not done mixed-method research?

#### Paper 1

This paper was about the analysis of usage of spyware speakers in homes of the elderly. The research did not cover any qualitative issues such as how they felt about it or what type of commands were used, although the type of commands were gathered, this data was not subject to any analysis. They purely focused on how much usage the participants had with the device. The paper was not mixed method however it could have become so if they chose to analyse other facets of the data they collected, however that was outside the scope of the paper.

#### Paper 2

have no idea what the f this paper is saying, theres lots of algebra in it tho so i guess its quantitative.

#### Paper 3

This studies the competence level of nurses before and after receiving simulated training in dealing with a specific situation, so the research evaluated their skills and knowledge by taking a test, receiving training from the simulation, then retaking the test to analyze the difference in results, stating that the improvement was due to the simulation training. at first it appears that it might be qualitative because you're evaluating the knowledge and skills of a person, that is something that inherently cannot be accurately measured with numbers in my opinion. but in the paper, the data that gets analyzed is simply the before and after test skills, which makes it quantitative. personally i do not believe the skills and knowledge of a person can be represented fairly in a test made up of questions and essays. there could be too many factors in it that might be unreliable, such as reading/writing comprehension or memory retention for academically inclined things, or rather, some of the participants may be medical geniuses while working practically, but unable to translate that into paper. i believe the authors could have gotten a better result from analysis and observation of their performance at work rather than just taking a test and getting their conclusion from numbers.

#### Paper 4

Uses a mixed method research technique, qualitative for parts then quantitative for further analysis into those original parts. the paper is quite lengthy and covers a range of data so mixed methods are good for the authors to get a complete understanding of their subject.

## Thoughts
Activities around qualitative and quantitative research. This will be helpful for later on when doing assignment, to understand the jargon related to research. I got a little sidetracked when answering questions, starting to argue about the topic of the research and my opinion on it or what they could have done better rather than addressing the methods objectively.


# Week 3
## Classwork

| language | pros | cons |
|-|-|-|
|**javascript** | fast, easy, super interactive webpages can be built with it | pretty vulnerable to attacks like XSS
|  | big community which means lots of plugins and helpful stuff | code is run client side in browser |
| | | single-threaded so it can only process one thing at a time, making it slower |
| **c#** | object oriented, making it complex | complexity also means harder to learn |
| | older language, making the knowledge db over the years thorough if you want resources | developed by microsoft |
| | | can be prone to memory leaks |
| **python** | good for data science, machine learning, and scientific computing | its interpreted rather than compiled which means less secure |
| | has tons of libraries you can easily integrate |
| **rust** | secure language | new, meaning it doesnt have many community resources, libraries, etc |
| | targets both low level and high level features unlike a language built for only one | a bit slower bc of safety checks during compilation |
| | uses multiple threads and cores, so can process many tasks at once | 

---

1. There are 6 sentences. For each sentence, determine if the sentence is using description, analysis, or evaluation (or a combination). Justify your decision.  
2. For the extract as a whole: What “description” type questions (What/Where/Who/When) are answered? What other “description” questions could be answered?  
3. What “analysis” type questions (How/Why/What if) are answered? What other “analysis” questions could be answered?  
4. What “evaluation” type questions (“So what/What next) are answered? What other “evaluation” questions could be answered?  
5. What are some other problems you can identify with the extract?  

---

**1.**  
**Sentence 1:** _Descriptive - what_. Explains what social engineering is.  
**Sentence 2:** _Descriptive - how_. Explains the basis of how social engineering works.  
**Sentence 3:** _Descriptive - what_. The sentence is simply stating that the attacks are carried out in one or more steps. This sentence could probably be the start of a bulleted list rather than a block since he goes on to describe steps in a process.  
**Sentence 4:** _Descriptive - what_. The sentence describes what the hacker does.  
**Sentence 5:** _Descriptive - what_. The sentence describes the next step of the attacker.  
**Sentence 6:** _Descriptive - how_. The sentence states how a victim falls to an attack.  

---

**2.** The extract is compromised of descriptive answers. It tells us the basic premise of social engineering, a short sentence of how it works, and then following a process of how a basic attack could be executed. There could have been more in depth explanations given rather than what we got.  

---

**3.** There are no analysis questions or answers in this extract. The writer could have talked about why in today's world it is so easy to perform social engineering attacks with social media and the majority of young people not caring about privacy (see statistics of young peoples privacy invading app social media usage, ask literally any of them if they care about everything they do being tracked (Literally the other week I know 2 people who got their accounts hacked purely from being stupidly trusting and not thinking critically about what random strangers are saying to them)).  

---

**4.** There are also no evaluation questions or answers in this extract. He could talk about consequences of the aforementioned lack of regard for privacy via social engineering attacks. He could offer solutions to not being attacked.  

---

**5.** The extract seems to be written by a non-native English speaker, as some sentence are using the wrong forms of words. I'm not a grammar major so I don't know the proper technical terms for this stuff but parts like "please have your password" and "a hacker does some investigations" is a telltale sign that the writer only knows English as his second language, so it makes sense that there would be a lot of basic mistakes in sentence construction. Aside from that there are also better ways to set out the entire thing, including using better punctuation like speech marks around certain parts too.

---

1.  How do these relate to the "Describe, Analyse, Evaluate" above?
2.  How do the verb lists help with identifying questions you might want to answer in a report?
3.  Choose two verbs from each level and create an IT-related question for each verb that a report-reader might expect to be answered. You can use the social engineering context from earlier, or chose an IT context of your own.

1.  These relate to design, analyse, and evaluate because they are part of the larger process of Blooms taxonomy.
2.  The verb list helps because it's using keywords that encompass the entire idea on each level of the taxonomy, just like writing down key points in a speech to help you remember the rest of the topic you were going to talk about, it is easier for human memory to be proc'd (procedure triggered by a specific circumstance) by the word, consequently remembering all of the shit behind it.
3.  Investigate web application security and then make recommendations for solutions to these issues

## Thoughts
Critical thinking is teaching us to look beyond the fluff and filler of what is written in a sentence we might read on the internet or in real life. To go deeper into a statement and ask questions about it. To keep our minds open about what other motivations may be behind an idea or thought process. Using logic in your thinking skills rather than blind belief or trusting anything that you read or someone tells you is important for a life skill in general.


# Week 4
## Classwork
### Ethics

-   What definition does the video give of ethics?
    -   A philosophy that humans live by, like a moral code that we use to base our decisions off and decide what kind of person we are  
 

-   Do you agree with the definition of values and beliefs that were presented in the video?
    -   the definition of values and beliefs according to the video was just "things that shape our choices". so, sure.  
 

-   Think (and write down) a few of your values, beliefs, and principles.
    -   idk these arent just things i can think of on the spot like this. im bad at that

-   What are some social norms? Are there social norms specific to the tech industry?
    -   i can think of a bunch of social norms but stuff like socialisation and the way people act/are expected to act could easily just be sex based stereotypes, most of which are primitive in todays society, like ones that have outdated mindsets based on generations of misogyny, which i do not want to give voice to.

### Research Ethics 

-   How does this video define ethics (again, the transcript in YouTube can help)? How does it compare with the definition of ethics in the previous video?
    -   It says ethics are the norms of conduct that promotes ideal human behaviour, and gives examples telling us what our ethics code should be.   

-   At 1:04 the video states that plagiarism, cheating, and fabrication of information are unethical. Why do you think they are unethical?
    -   because its trying to pass other peoples work as your own so lying for one thing, trying to get into a field you dont understand for yourself will only end up being detrimental for you and everyone else around you, and hinders progress in that area too.

-   Find the Research Ethics page in the NMIT intranet. What are the three types of approval that you might need for research?
    -   NMIT Animal Ethics Committee
    -   Human participant
    -   Health Research Council Ethics Committee

-   Find an example of research (recent or historic) that you consider unethical. Explain you reasoning.
    -   i think an interesting unethical experiment was the stanford prison experiment. it is said that the participants were normal college students, not like anyone that would be used to being in a position that they abused authority. the fact that random men just turned into absolute subhumans when given a power advantage (guard role) over the prisoner participants, speaks miles on male conditioning in my opinion. if you conducted this experiment with only women i guarantee you that it would have gone differently. it shows how easily men turn into psychopaths if given the chance. anyway thats kinda off the point - it was unethical because the prisoner participants were not informed properly about what they would be enduring. obviously the initial proposal for the experiment didnt anticipate what vile beasts these men would become when allowed to have free reign like that.

## Thoughts
Nothing really new to learn here. This class is about ethics and just shows us a bunch of videos talking about morals. The only ethics we really need to adhere to in the context of learning about IT is do not plagiarise. The rest of what we were shown and our exercises in the wiki were unrelated to IT. Social norms, unethical experiments. 

# Week 5
## Classwork
### Cognitive

-   **What are you thoughts and opinions on the article? Do you agree?**
    -   I wouldn't even be able to remember the four big problems as the article states. Even with the explanation its confusing and it's already gone from my head as of typing this after reading it about 3 times over. This guy seems to have done a lot of research into the area so he probably knows what he's talking about so sure I can agree with what hes saying.  
    

-    **What are the four consequences of our brain's solution to deal with the world? Can you think of an example where you have run in to these problems?**
    -   we dont see everything, search for meaning can conjure illusions, quick decisions can be flawed, memory reinforces errors.
    -   sure i make quick decisions all the time, well rather jump to assumptions because of feeling a certain way impulsively. and then its only later when you have settled down and had time to think things through more thoroughly that you can understand another way of thinking about it.

### Research

-    Choose 3 biases from the list of 10, and describe the bias in your own words. Give one or two examples of the bias in an IT-related context. Provide some advice for how to avoid the bias.

1.  **Sampling Bias** - this is when a survey or something to gather data is done and the results of it may not be accurate to representing the views of a larger scale than the sample. In the context of IT, this could be where machine learning algorithms need to be trained on data, but they use data from a particular demographic, which may not be accurate or effective for other demographics. to avoid this bias, data should be gathered from a diverse range.
2.  **Recall Bias** - this is when recollection of past events are affected by the present. For IT this could be a user participating in a study that needs user feedback, and is unable to recall their experience with the software or website in question properly, leading them to make incorrect statements about how they experienced it, making the results unreliable. to avoid this, conduct the tests in real time.  
    
3.  **Question Order Bias** - when the previous question is worded in a way that sort of manipulates you into thinking about that for the next question. like theyll say something negative in the former question then you will be focused on that going forwards into next questions. An example of this in IT could be the same as the recall one, when a user it taking a survery based on user experiences within an app, the questions could be worded in a way that affects their response.
    1.  How satisfied are you with the software?
    2.  Which features do you use the most?

If the user has a negative response to the first question, then they might focus of the negative aspects for the second. avoiding this is easy, just randomize the order of questions.  

  

### 1080 Bias 

Answer questions such as: Who is/are the author(s)? What are their credentials? How are their claims justified? Is there a non-scientific (monetary? fame?) motivation for their claims (funding bias)? Is there confirmation bias or cherry picking of results - and how do you know? Is there sampling bias (the "caveman" effect)? Reporting bias? Other biases? Note both actual biases (where there is evidence of bias) and possible biases (where you suspect there could be bias). Ensure you give reasons. you can also use the critical thinking questions from the class two weeks ago.


The main bias that stands out to me is that the author of each piece written on the 1080science main page, has an initial bias about the use of 1080, aside from the last reply by Ron Eddy, affiliation unknown. The first author, Dr Jo Pollard, is an anti 1080 activist, and the second author, Dave Hansford, is a journalist who works in conjunction with environmental organisations and is known to be pro 1080, having written books about it. So they are both arguing to prove their own opinions on whether it is good or bad. The most objectional piece here can be found written by the unknown party who isn't really giving a solid opinion on the side he is on, but rather challenges the reader to find facts on their own, while proving some statements by Hansford to be factually incorrect.

It's kind of hard to pick out the biases around it aside from that, because in all of the articles, each author is challenging scientific studies and saying the info is cherry picked, some data is not included or incomplete, and accusing each other of being wrong about statistics from their studies. I wouldn't be able to to challenge any of it or argue about any biases without going through the references and looking at the info for myself.

The website 1080facts is biased in and of itself because it is a website supported by doc and pest control organisations.

## Thoughts
Learning about bias would probably be applicable to the project during the report when we have to evaluate. there is inevitably going to be bias because we are the creators of our own work and of course we think its good when we've made it ourselves. this is also where critical thinking can apply, to try and look at your work as objectively as possible so you can evaluate it with as little bias as possible.

# Week 6
## Classwork

**What is an "academic article" (or "academic paper", or "research paper")?**
an article that has passed an academic quality test and has been published in an academic journal  

**What is an "academic article" (or "academic paper", or "research paper")?**
an article that has passed an academic quality test and has been published in an academic journal  

**Why would we want to read an academic paper?**
if its relevant to something were studying ourselves and we need to glean info from it  

**Where are some places we could look for (and read) an academic paper in the IT field?**
just web search it  

**What is peer-review? What is "impact factor". What is a "predatory journal or "predatory publisher" or "predatory conference"?**
peer review is when one of your peers review your thing? impact factor is the measure of influence a paper has in its academic circle. all the predatory stuff is like things that are deceptive and spread misinformation and do dodgy stuff  

**Academic papers come in a few types, including "research papers", "survey papers", "case studies", "perspective papers". What do these terms mean?**
theyre descriptions of different types of papers

### Academic paper reviews

-   Title and author(s) of the article   
    -   The inhospitable vulnerability: A need for cybersecurity risk assessment in the hospitality industry - [Chen, Hsiangting Shatina](https://www.proquest.com/indexinglinkhandler/sng/author/Chen,+Hsiangting+Shatina/$N?accountid=40261 "Click to search for more items by this author"); [Fiscus, Joseph](https://www.proquest.com/indexinglinkhandler/sng/author/Fiscus,+Joseph/$N?accountid=40261 "Click to search for more items by this author").

-   APA reference (give it your best shot!) (try using the ‘cite’ option on Google Scholar or other online resource. We'll cover references in a future class)
    -   Chen, H. S., & Fiscus, J. (2018). The inhospitable vulnerability: A need for cybersecurity risk assessment in the hospitality industry. _Journal] of Hospitality and Tourism Technology,_ _9_(2), 223-234. doi:[https://doi.org/10.1108/JHTT-07-2017-0044](https://doi.org/10.1108/JHTT-07-2017-0044)
  
-   How you found the article  
    -   Browsing on proquest  
 
-   What kind of article it is, ( journal paper, conference paper, masters thesis.....)
    -   Journal article  
   
-   How well it fits the 'structure of an academic article' that described above
    -   somewhat follows structure  

-   How many references it has
    -   29 references  

-   How many citations it has (if you can find out!)
    -   looks like you can only see the number of citations a paper has within the given website you found it on, so without going around to different sites looking for it, ill say on proquest where i found this article, it only has 1 citation (presumably by myself, in one of the previous questions for this activity)  

-   The URL of the article
    -   [https://www.proquest.com/docview/2132304371/8F68D2CB63314B84PQ/61?accountid=40261](https://www.proquest.com/docview/2132304371/8F68D2CB63314B84PQ/61?accountid=40261)  
 
-   A 1-2 sentence summary of the article.
    -   paper details past cyber attacks on hospitality industry and their consequences, warning on direct impact of guests, assessing the risks and evaluating the vulnerabilities, as well as recommendations for hospo operators.  

-   Some indications of the possible credibility of the article.
    -   has been published in a journal for technology  

---


-   Title and author(s) of the article 
    -   Women in Cybersecurity: A Study of the Digital Banking Sector in Bahrain - [Al-Alawi, Adel Ismail](https://www.proquest.com/indexinglinkhandler/sng/author/Al-Alawi,+Adel+Ismail/$N?accountid=40261 "Click to search for more items by this author"); [Al-Khaja, Noora Ahmed](https://www.proquest.com/indexinglinkhandler/sng/author/Al-Khaja,+Noora+Ahmed/$N?accountid=40261 "Click to search for more items by this author"); [Mehrotra, Arpita Anshu](https://www.proquest.com/indexinglinkhandler/sng/author/Mehrotra,+Arpita+Anshu/$N?accountid=40261 "Click to search for more items by this author").  

-   APA reference (give it your best shot!) (try using the ‘cite’ option on Google Scholar or other online resource. We'll cover references in a future class)
    -   Al-Alawi, A., Al-Khaja, N., & Mehrotra, A. A. (2023). Women in cybersecurity: A study of the digital banking sector in bahrain. _Journal of International Women's Studies,_ _25_(1), 1-20. Retrieved from [https://www.proquest.com/scholarly-journals/women-cybersecurity-study-digital-banking-sector/docview/2778390787/se-2](https://www.proquest.com/scholarly-journals/women-cybersecurity-study-digital-banking-sector/docview/2778390787/se-2)

-   How you found the article
    -   proquest search  

-   What kind of article it is, ( journal paper, conference paper, masters thesis.....)
    -   journal paper  

-   How well it fits the 'structure of an academic article' that described above
       -   fits well  

-   How many references it has
    -   21  

-   How many citations it has (if you can find out!)
    -   cant find out  

-   The URL of the article
	-   [https://www.proquest.com/docview/2778390787/8F68D2CB63314B84PQ/77?accountid=40261  

-   A 1-2 sentence [summary](https://ecampus.nmit.ac.nz/moodle/course/view.php?id=13776&section=16 "Summary") of the article.
    -   talks about challenges and limitations of women in the industry, as well as contributions in the field by women. highlights the shortage and need for improvement. specifically details this within the banking sector.  

-   Some indications of the possible credibility of the article. 
    -   again it was published in an academic [journal](https://ecampus.nmit.ac.nz/moodle/course/view.php?id=13776&section=1 "Journal") and the authors all have names that seem to originate from the country that their paper addresses, so more credible to have authors that originate from bahrain than foreign ones.

## Thoughts
Summarising the main points of an academic paper. This basically follows the layout of any paper they make you write all throughout education, just adding a few more sections like the abstract. Has to follow the strict structure. Uses a bit of critical thinking from a previous lesson to judge whether a paper may be credible or not, analysing other parts of the paper.

# Week 7
No classwork or thoughts were really done this week because it was about the assigment for writing a mock up project proposal, which I have already done for real

# Week 8
## Classwork
I'm hesistant to paste in all the work from the wiki this week because its a massive table and formatting it here again would be a pain, so heres half of it.

### Using Perplexity to follow the steps to come up with a research question

**Q: list some broad topics in information technology that could be used for research**

A: There are many broad topics in information technology that could be used for research.

Some examples include:

-   IT management
-   analytics in organizations and social media
-   the use of the internet to communicate
-   computer science and robotics
-   blockchain technology
-   the impact of information technologies on human life
-   cybersecurity
-   artificial intelligence
-   big data
-   cloud computing
-   mobile computing
-   e-commerce
-   social networking

When choosing a topic, it is important to consider your interests, the current state of the field, and the potential impact of your research. You can consult with your supervisor or mentor to get feedback on your proposed topic and narrow down your ideas. By selecting a broad topic that is relevant to the field of IT, you can develop a research question that is focused, specific, and relevant to a timely social or scholarly issue


**Q: conduct a literature review to identify gaps of knowledge or controversies within the area of blockchain technology**

A: A literature review of blockchain technology reveals several gaps in knowledge and controversies within the field. Some of the gaps in knowledge include the need for more research on the security properties, applications, and challenges of blockchain technology.

Additionally, there is a need for more research on the impacts and challenges of blockchain technology in practice, particularly in the areas of decentralized data storage and secure transactions. There is also a need for more research on the use of blockchain technology in education, as well as its potential applications in rural development and sustainability.  

Controversies within the field include the debate over the scalability of blockchain technology, as well as concerns over its energy consumption and environmental impact. By conducting a comprehensive literature review of blockchain technology, researchers can identify these gaps in knowledge and controversies, and develop research questions that address these issues.


**Q: formulate a research question on the impact and challenges of blockchain technology in practice, particularly focusing on the area of decentralised data storage**

A: _What are the challenges and impacts of using blockchain technology for decentralized data storage in practice?_  
This research question aims to investigate the practical implications of using blockchain technology for decentralized data storage, including the challenges and impacts of this approach. The study will focus on the security, privacy, and scalability of blockchain technology for data storage, as well as the potential benefits and drawbacks of this approach. The research will involve a comprehensive literature review of existing studies on blockchain technology and decentralized data storage, as well as case studies of organizations that have implemented this approach. The findings of this study will contribute to a better understanding of the practical implications of using blockchain technology for decentralized data storage and inform the development of best practices for implementing this approach in practice.


**Q: you are an expert in the field of blockchain technology, can you give some feedback on the research question from the previous answer, come up with any issues surrounding it?**

A: Based on the available search results, the research question on the challenges and impacts of using blockchain technology for decentralized data storage in practice seems relevant and important. One potential issue with this research question is that it may be too broad and may require further refinement to focus on specific aspects of blockchain technology and decentralized data storage.

For example, the study could focus on the security challenges of using blockchain technology for decentralized data storage, or the scalability issues associated with this approach. Additionally, the study may need to consider the potential impact of other emerging technologies, such as artificial intelligence, on the use of blockchain technology for decentralized data storage.

Overall, the research question is a good starting point for investigating the practical implications of using blockchain technology for decentralized data storage, but it may require further refinement to address specific research gaps and controversies in the field.

## Thoughts
This was a really interested class aimed at how to get the most out of prompts for AI in order to augment your study and work by using it as an assistant to help you come up with ideas or motivate you when you feel stuck. Showing the differences between multiple different AI bots and which would answer questions the best. This is a valuable tool for anyone who works in an area where they need to figure out how to do something. Having it as an aid can provide insight and answers you need to continue your own work.

# Week 9
## Classwork
Created APA citations and references

## Thoughts
Nothing new here like every class ever when writing a paper you have to do references and cite sources used. if someone is at level 7 and doesn't know how to do this properly then i would be really worried.

# Week 10
## Classwork
### **What are the five areas of Intellectual Property Law? Give an example for each area. Does the area relate to software in any way?**

1.  Copyright: Federal copyright law protects original creative works such as paintings, writing, architecture, movies, software, photos, dance, and music. A work must meet certain minimum requirements to qualify for copyright protection  
    _Example: A software company creates a new program and wants to protect it from being copied or used without permission._

  

2.  Trademarks: Trademarks are used to protect brand names, logos, and slogans that identify and distinguish goods or services in the marketplace  
    _Example: A company creates a new logo and wants to prevent others from using it without permission._

  

3.  Patents: Patents are used to protect inventions and give the inventor the exclusive right to make, use, and sell the invention for a certain period of time  
    _Example: A scientist invents a new drug and wants to prevent others from making or selling it without permission._

  

4.  Trade Secrets: Trade secrets are confidential information that gives a business an advantage over competitors. They are not known by competitors and are kept secret  
    _Example: A company has a secret recipe for a popular food item and wants to prevent others from using or copying it._

  

5.  Industrial Design Rights: Industrial design rights protect the visual design of objects that are not purely utilitarian.  
    _Example: A company creates a unique design for a new car model and wants to prevent others from copying it._

  

### **Answer these questions in your wiki about copyright in NZ.**

If you come from another country (or a going to another country after graduation) you can answer the questions for that country instead if you wish: 

-   **What material does it protect?**
    -   The categories of work protected by copyright include:
        
        -   Literary works material that is written, spoken, or sung, including words of a book, song, poem, magazine, article, speech. This category also includes tables, compilations and computer programs.
        -   Dramatic works including plays, works of dance or mime, film scenarios, scripts.
        -   Artistic works including paintings, drawings, diagrams, maps, photographs.
        -   Musical works musical compositions (scores and sheet music).
        -   Typographical works the typographical arrangement of words and associated elements in published editions, such as books, magazines, journals, newspapers, posters, and websites.
        -   Sound recordings, films and communication works (such as broadcasts and internet transmissions) are other categories of work protected by copyright.

-   **Who gets (owns) the copyright?**
    -   The creator of an original work such as the author or artist is usually the first owner of any copyright in that work. There are two main exceptions:
        
        -   where a work is created in the course of employment, the employer will own copyright;
        -   where someone commissions, and agrees to pay for certain types of work – a photograph, painting, drawing, diagram, map, chart, plan, engraving, model, sculpture, film, sound recording or computer program – the commissioner will own copyright.
  
-   **How do they get copyright ownership?**
    -   Copyright protection comes into existence automatically once an original work is written down or recorded in some way. Registration of copyright is not required and there is no formal system for recording copyright in New Zealand.

-   **How long does copyright last?**
    -   In New Zealand, copyright in literary, dramatic, musical and artistic works lasts for the life of the author plus fifty years from the end of the year in which the author dies. For a work of joint authorship, the fifty years runs from the death of the last surviving author.
        Copyright in the typographical arrangement of a published edition lasts for 25 years from the end of the year of publication. Other types of copyright material have slightly different periods of protection.
        
        The period of copyright protection is longer in Australia, Europe and the United States − generally 70 years from the end of the year in which the author dies.

-   **What rights does the owner have?**
    -   -   Copy the work;
        -   Issue copies of the work to the public for the first time (often called the “publishing right”);
        -   Perform, play or show the work in public;
        -   Communicate the work to the public (on radio, TV, transmitting electronically or make available online); and
        -   Adapt the work (including to translate a poem from one language to another or adapt a novel into a film script) and do any of the above activities in relation to an adaptation.
        -   -   the right to be identified as the author of the work (the right of attribution);
            -   the right to object to derogatory treatment of the work (the right of integrity); and
            -   the right to not have a work falsely attributed to them.
  

### **Software Licenses** 

**sqllite**
Public domain

**Linux kernel**
[GPL-2.0-only](https://en.wikipedia.org/wiki/GNU_General_Public_License) with Linux-syscall-note.

**Libre Office**
[MPL-2.0](https://en.wikipedia.org/wiki/Mozilla_Public_License)

**falsisign**
[WTFPL license](https://github.com/anak10thn/WTFPL/blob/master/LICENSE.txt)  

**nodebestpractices**
[CC-BY-SA-4.0 license](https://github.com/goldbergyoni/nodebestpractices/blob/master/LICENSE)  

**SharpKeys**
[MS-PL license](https://github.com/randyrants/sharpkeys/blob/master/license.md)  

**Open-PS2-Loader**
[AFL-3.0 license  
](https://github.com/ps2homebrew/Open-PS2-Loader/blob/master/LICENSE)
**Python**
[Python Software Foundation License](https://en.wikipedia.org/wiki/Python_Software_Foundation_License)

**json**
The JSON license is a slightly modified variant of the [MIT license](https://github.com/d3aths/web701-project/blob/master/LICENSE), but that variation has led it to be rejected as a free-software or open-source license by several organizations. The change is a simple—rather innocuous at some level—addition of one line: "The Software shall be used for Good, not Evil.". Up until recently, code using the JSON license was acceptable for Apache projects, but that line and the ambiguity it engenders was enough for Apache to put it on the list of disallowed licenses.

**mrmo-halftone**
"Basic" version license: MRMO-Halftone "Basic" version can be used in non-commercial projects of any kind, _excluding_ those relating to or containing non-fungible tokens ("NFT") or blockchain-related projects.  

### **What License Would I Use?** 
If you write some code (or create some other type of resource), what license would you use and why?  

I would use the evil-license for this purpose. Because it resonates with me a lot.  

Found here [https://github.com/ErikMcClure/bad-licenses/blob/master/evil-license](https://github.com/ErikMcClure/bad-licenses/blob/master/evil-license)  

  

Copyright (c) (year) (copyright holder)  
  
Permission is hereby granted, free of charge, to any person obtaining a copy  
of this software and associated documentation files (the "Software"), to deal  
in the Software with specific restrictions, provided that the user intends  
to use the Software explicitly FOR the purposes of evil or advancing evil,  
including but not limited to:  
  
Genocide, Wanton Destruction, Fraud, Nuclear/Biological/Chemical Terrorism,  
Harassment, Prejudice, Slavery, Disfigurement, Brainwashing, Ponzi Schemes  
and/or the Destruction of Earth itself,  
  
with this, including without limitation the rights to copy, modify, merge,  
publish, distribute, sublicense, sell and/or run copies Software or any  
executable binaries built from the source code.  
  
The above copyright notice and this permission notice shall be included in all  
copies or substantial portions of the Software.  
  
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR  
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,  
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE  
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER  
LIABILITY, THAT WILL ASSUREDLY HAPPEN BECAUSE THE SOFTWARE IS MEANT TO BE  
USED EXPLICITLY FOR EVIL, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,  
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER  
DEALINGS IN THE SOFTWARE


## Thoughts
Interesting seeing just how many different licences there are, is there really a need for so much random ones? Anyone can make up a licence and say whatever they feel like, as demonstrated above. I think its fairly pointless to be honest. Not sure of the use within the project. I'm writing my own program, but using a tutorial to help with the code. Does that mean it's mine and i can put a copyright and licence on it, even if the source has technically been written by someone else and I was the one who put it together and changed it to suit my needs? Where does the line lie for intellectual property in a situation like that?